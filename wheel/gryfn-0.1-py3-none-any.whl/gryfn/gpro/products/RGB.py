import logging
from .Product import Product


class RGB(Product):
    pass

