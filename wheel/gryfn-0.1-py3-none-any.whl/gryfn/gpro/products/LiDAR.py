from .Product import Product


class LiDAR(Product):
    pass
