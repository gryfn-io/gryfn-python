from .Product import Product


class GNSS(Product):
    pass
