from .Hyperspectral import Hyperspectral


class VNIR(Hyperspectral):
    pass
