from .Hyperspectral import Hyperspectral


class SWIR(Hyperspectral):
    pass
